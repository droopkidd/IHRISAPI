<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\TrainingInstitutionController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\TrainingsController;

Route::get('/api/training-institutions/count', [TrainingInstitutionController::class, 'getTrainingInstitutionsCount']);
Route::get('/api/students/distribution', [TrainingInstitutionController::class, 'getStudentDistribution']);
Route::get('/api/students/count', [StudentController::class, 'getCurrentStudentsCount']);
Route::get('/api/students/graduates', [StudentController::class, 'getGraduates']);
Route::get('/api/trainings/schedules',[TrainingsController::class, 'getSchedules']);