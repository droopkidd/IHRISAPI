<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CurrentStudent extends Model
{
    protected $table = 'zebra_current_students';

    // Define any relationships if needed
    public function trainingInstitution()
    {
        return $this->belongsTo(TrainingInstitution::class, 'primary_form+parent', 'primary_form+id');
    }
}
