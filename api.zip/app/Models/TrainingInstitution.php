<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingInstitution extends Model
{
    protected $table = 'zebra_training_institutions';

    // Define any relationships if needed
    public function students()
    {
        return $this->hasMany(CurrentStudent::class, 'primary_form+parent', 'primary_form+id');
    }
}
