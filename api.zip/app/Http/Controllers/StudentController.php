<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    /**
     * Get the total number of current students.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getCurrentStudentsCount()
    {
        $total = DB::table('zebra_current_students')->count();
        return response()->json(['total' => $total]);
    }

    public function getGraduates()
    {
        $total = DB::table('zebra_former_students')->count();
        return response()->json(['total' => $total]);
    }
}
