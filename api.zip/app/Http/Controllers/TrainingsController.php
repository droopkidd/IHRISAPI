<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TrainingsController extends Controller
{
    //
    public function getSchedules()
    {
        $total = DB::table('zebra_scheduled_training')->count();
        return response()->json(['total' => $total]);
    }
}
