<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\CurrentStudent;
use App\Models\TrainingInstitution;

class TrainingInstitutionController extends Controller
{
    /**
     * Get the total number of training institutions.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getTrainingInstitutionsCount()
    {
        $total = DB::table('zebra_training_institutions')->count();
        return response()->json(['total' => $total]);
    }


    public function getStudentDistribution()
    {
        $label = 'primary_form' . '+' . 'name';
    
        // Fetch and group data using Eloquent
        $data = TrainingInstitution::withCount('students')
            ->get()
            ->map(function ($institution) use ($label) {
                return [
                    'label' => $institution[$label], 
                    'value' => $institution->students_count,
                ];
            });
    
        return response()->json(['data' => $data]);
    }
    
    }
